# CelestiaGS
Gameserver made for Celestia (13.40), made by me and max
