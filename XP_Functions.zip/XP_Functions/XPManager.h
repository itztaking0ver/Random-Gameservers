#pragma once

#include "../Object.h"
#include "../Actor.h"
#include "XPComponent.h"

/**
 * XP Manager class for centralized XP system management
 * This class provides high-level functions for managing XP across the game
 */
class UFortXPManager
{
public:
    /**
     * Initialize XP system for all players
     * This should be called when the game starts
     */
    static void InitializeXPSystem();

    /**
     * Shutdown XP system
     * Clean up XP-related resources
     */
    static void ShutdownXPSystem();

    /**
     * Process XP for a specific player
     * @param PlayerActor The player to process XP for
     * @param XPAmount The amount of XP to award
     * @param XPType The type of XP (kill, survival, etc.)
     */
    static void ProcessXPForPlayer(AActor* PlayerActor, int XPAmount, const FString& XPType);

    /**
     * Award XP to a player
     * @param PlayerActor The player to award XP to
     * @param XPAmount The amount of XP to award
     * @param bNotifyClient Whether to notify the client
     */
    static void AwardXP(AActor* PlayerActor, int XPAmount, bool bNotifyClient = true);

    /**
     * Get total XP for a player
     * @param PlayerActor The player to get XP for
     * @return Total XP amount, or -1 if error
     */
    static int GetPlayerTotalXP(AActor* PlayerActor);

    /**
     * Get player level based on XP
     * @param PlayerActor The player to get level for
     * @return Player level, or -1 if error
     */
    static int GetPlayerLevel(AActor* PlayerActor);

    /**
     * Check if XP system is initialized
     * @return true if initialized, false otherwise
     */
    static bool IsXPSystemInitialized();

private:
    static bool bXPSystemInitialized;
    static int TotalXPAwarded;
    static int TotalPlayersProcessed;
};
