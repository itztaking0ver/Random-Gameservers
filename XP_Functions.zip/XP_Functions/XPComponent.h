#pragma once

#include "../Object.h"
#include "../UObjectGlobals.h"
#include "../Function.h"

/**
 * XP Component class for handling player experience points and quest management
 * This component is responsible for managing XP-related functionality in Fortnite
 */
class UFortPlayerControllerAthenaXPComponent : public UObject
{
public:
    /**
     * Get the XP Component from a player actor
     * @param PlayerActor The player actor to get the XP component from
     * @return Pointer to the XP component, or nullptr if not found
     */
    static UObject* GetXPComponent(AActor* PlayerActor)
    {
        if (!PlayerActor)
            return nullptr;

        static auto XPComponentOffset = PlayerActor->GetOffset("XPComponent", false);
        
        if (XPComponentOffset == -1)
            return nullptr;

        return PlayerActor->Get(XPComponentOffset);
    }

    /**
     * Register the XP component with the quest manager
     * @param XPComponent The XP component to register
     * @return true if registration was successful, false otherwise
     */
    static bool RegisterWithQuestManager(UObject* XPComponent)
    {
        if (!XPComponent)
            return false;

        static auto bRegisteredWithQuestManagerOffset = XPComponent->GetOffset("bRegisteredWithQuestManager");
        
        if (bRegisteredWithQuestManagerOffset == -1)
            return false;

        // Set the registration flag
        XPComponent->Get<bool>(bRegisteredWithQuestManagerOffset) = true;

        // Call the replication function
        static auto OnRep_bRegisteredWithQuestManagerFn = FindObject<UFunction>("/Script/FortniteGame.FortPlayerControllerAthenaXPComponent.OnRep_bRegisteredWithQuestManager");

        if (OnRep_bRegisteredWithQuestManagerFn)
        {
            XPComponent->ProcessEvent(OnRep_bRegisteredWithQuestManagerFn);
            return true;
        }

        return false;
    }

    /**
     * Check if the XP component is registered with the quest manager
     * @param XPComponent The XP component to check
     * @return true if registered, false otherwise
     */
    static bool IsRegisteredWithQuestManager(UObject* XPComponent)
    {
        if (!XPComponent)
            return false;

        static auto bRegisteredWithQuestManagerOffset = XPComponent->GetOffset("bRegisteredWithQuestManager");
        
        if (bRegisteredWithQuestManagerOffset == -1)
            return false;

        return XPComponent->Get<bool>(bRegisteredWithQuestManagerOffset);
    }

    /**
     * Initialize XP component for a new player
     * This function handles the setup of XP-related functionality when a player joins
     * @param PlayerActor The player actor to initialize XP for
     * @return true if initialization was successful, false otherwise
     */
    static bool InitializeXPForPlayer(AActor* PlayerActor)
    {
        if (!PlayerActor)
            return false;

        auto XPComponent = GetXPComponent(PlayerActor);
        
        if (!XPComponent)
            return false;

        return RegisterWithQuestManager(XPComponent);
    }
};
