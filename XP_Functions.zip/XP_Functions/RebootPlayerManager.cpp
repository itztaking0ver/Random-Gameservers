#include "RebootPlayerManager.h"
#include "../log.h"
#include "../globals.h"

// Implementation of Reboot Player Manager functionality
// This file contains the actual implementation of reboot player management functions

namespace RebootPlayerUtils
{
    /**
     * Initialize reboot player settings
     * This function sets up the default configuration for reboot players
     */
    void InitializeRebootPlayerSettings()
    {
        LOG_INFO(LogPlayer, "Initializing Reboot Player Settings");
        LOG_INFO(LogPlayer, "  Allow Reboot Players: {}", Globals::bAllowRebootPlayer ? "Enabled" : "Disabled");
        LOG_INFO(LogPlayer, "  Remove Reboot Prefix: {}", Globals::bRemoveRebootFromPlayerName ? "Enabled" : "Disabled");
    }

    /**
     * Process all connected players for reboot player rules
     * This function should be called periodically to check all connected players
     */
    void ProcessAllPlayersForRebootRules()
    {
        // This would typically iterate through all connected players
        // and apply reboot player rules as needed
        LOG_INFO(LogPlayer, "Processing all players for reboot rules");
    }

    /**
     * Log reboot player statistics
     * This function logs information about reboot player usage
     */
    void LogRebootPlayerStats()
    {
        LOG_INFO(LogPlayer, "=== Reboot Player Statistics ===");
        LOG_INFO(LogPlayer, "Configuration Status:");
        LOG_INFO(LogPlayer, "  Allow Reboot Players: {}", Globals::bAllowRebootPlayer ? "Yes" : "No");
        LOG_INFO(LogPlayer, "  Remove Reboot Prefix: {}", Globals::bRemoveRebootFromPlayerName ? "Yes" : "No");
        LOG_INFO(LogPlayer, "  Total Usernames Stored: {}", Globals::playerUsernames.size());
    }

    /**
     * Validate reboot player name
     * This function checks if a reboot player name is valid
     * @param PlayerName The player name to validate
     * @return true if valid, false otherwise
     */
    bool ValidateRebootPlayerName(const FString& PlayerName)
    {
        if (PlayerName.IsEmpty())
        {
            LOG_WARNING(LogPlayer, "Empty player name provided");
            return false;
        }

        std::string Name = PlayerName.ToString();
        
        // Check if name starts with reboot prefix
        if (!Name.starts_with("reboot_"))
        {
            LOG_INFO(LogPlayer, "Player name '{}' is not a reboot player", Name);
            return true; // Not a reboot player, so it's valid
        }

        // Check if name has content after the prefix
        if (Name.length() <= 7) // "reboot_" is 7 characters
        {
            LOG_WARNING(LogPlayer, "Invalid reboot player name: '{}' (no content after prefix)", Name);
            return false;
        }

        LOG_INFO(LogPlayer, "Valid reboot player name: '{}'", Name);
        return true;
    }

    /**
     * Get clean player name (without reboot prefix if applicable)
     * @param PlayerName The original player name
     * @return The clean player name
     */
    FString GetCleanPlayerName(const FString& PlayerName)
    {
        if (PlayerName.IsEmpty())
            return PlayerName;

        std::string Name = PlayerName.ToString();
        
        if (Name.starts_with("reboot_"))
        {
            std::string CleanName = Name.substr(7); // Remove "reboot_" prefix
            LOG_INFO(LogPlayer, "Cleaned player name: '{}' -> '{}'", Name, CleanName);
            return FString(CleanName);
        }

        return PlayerName;
    }

    /**
     * Check if a player controller is a reboot player
     * @param PlayerController The player controller to check
     * @return true if it's a reboot player, false otherwise
     */
    bool IsPlayerControllerRebootPlayer(AFortPlayerControllerAthena* PlayerController)
    {
        if (!PlayerController)
            return false;

        auto PlayerState = PlayerController->GetPlayerState();
        if (!PlayerState)
            return false;

        FString PlayerName = PlayerState->GetPlayerNameString();
        return UFortRebootPlayerManager::IsRebootPlayer(PlayerName);
    }

    /**
     * Apply reboot player rules to a specific player
     * @param PlayerController The player controller to apply rules to
     * @return true if rules were applied successfully, false otherwise
     */
    bool ApplyRebootPlayerRules(AFortPlayerControllerAthena* PlayerController)
    {
        if (!PlayerController)
        {
            LOG_ERROR(LogPlayer, "Null player controller in ApplyRebootPlayerRules");
            return false;
        }

        auto PlayerState = PlayerController->GetPlayerState();
        if (!PlayerState)
        {
            LOG_ERROR(LogPlayer, "Null player state in ApplyRebootPlayerRules");
            return false;
        }

        FString PlayerName = PlayerState->GetPlayerNameString();
        
        if (!UFortRebootPlayerManager::IsRebootPlayer(PlayerName))
        {
            LOG_INFO(LogPlayer, "Player '{}' is not a reboot player, no rules to apply", PlayerName.ToString());
            return true;
        }

        LOG_INFO(LogPlayer, "Applying reboot player rules to: '{}'", PlayerName.ToString());

        // Apply the rules using the manager
        bool bSuccess = UFortRebootPlayerManager::HandleRebootPlayerConnection(PlayerController);
        
        if (bSuccess)
        {
            LOG_INFO(LogPlayer, "Successfully applied reboot player rules");
        }
        else
        {
            LOG_WARNING(LogPlayer, "Failed to apply reboot player rules or player was kicked");
        }

        return bSuccess;
    }
}
