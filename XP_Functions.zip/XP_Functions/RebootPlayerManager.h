#pragma once

#include "../globals.h"
#include "../FortPlayerControllerAthena.h"
#include "../FortPlayerState.h"
#include "../UnrealString.h"
#include <string>

/**
 * Reboot Player Manager class for handling reboot player functionality
 * This class manages the behavior of players with "reboot_" prefix in their names
 */
class UFortRebootPlayerManager
{
public:
    /**
     * Check if reboot players are allowed to join
     * @return true if reboot players are allowed, false otherwise
     */
    static bool IsRebootPlayerAllowed()
    {
        return Globals::bAllowRebootPlayer;
    }

    /**
     * Set whether reboot players are allowed to join
     * @param bAllowed true to allow reboot players, false to deny them
     */
    static void SetRebootPlayerAllowed(bool bAllowed)
    {
        Globals::bAllowRebootPlayer = bAllowed;
    }

    /**
     * Check if reboot prefix should be removed from player names
     * @return true if prefix should be removed, false otherwise
     */
    static bool ShouldRemoveRebootPrefix()
    {
        return Globals::bRemoveRebootFromPlayerName;
    }

    /**
     * Set whether reboot prefix should be removed from player names
     * @param bRemove true to remove prefix, false to keep it
     */
    static void SetRemoveRebootPrefix(bool bRemove)
    {
        Globals::bRemoveRebootFromPlayerName = bRemove;
    }

    /**
     * Check if a player name starts with reboot prefix
     * @param PlayerName The player name to check
     * @return true if name starts with "reboot_", false otherwise
     */
    static bool IsRebootPlayer(const FString& PlayerName)
    {
        return PlayerName.ToString().starts_with("reboot_");
    }

    /**
     * Remove reboot prefix from player name
     * @param PlayerName The player name to process
     * @return The player name without the reboot prefix
     */
    static FString RemoveRebootPrefix(const FString& PlayerName)
    {
        std::string Name = PlayerName.ToString();
        std::string target = "reboot_";
        
        size_t pos = Name.find(target);
        if (pos != std::string::npos)
        {
            Name.replace(pos, target.length(), "");
        }
        
        return FString(Name);
    }

    /**
     * Handle reboot player connection
     * This function processes a player connection and applies reboot player rules
     * @param PlayerController The player controller to process
     * @return true if player should be allowed to continue, false if they should be kicked
     */
    static bool HandleRebootPlayerConnection(AFortPlayerControllerAthena* PlayerController)
    {
        if (!PlayerController)
            return false;

        auto PlayerState = PlayerController->GetPlayerState();
        if (!PlayerState)
            return false;

        FString PlayerName = PlayerState->GetPlayerNameString();
        
        // Check if this is a reboot player
        if (!IsRebootPlayer(PlayerName))
            return true; // Not a reboot player, allow connection

        // If reboot players are not allowed, kick them
        if (!IsRebootPlayerAllowed())
        {
            PlayerController->ClientReturnToMainMenu(L"Sorry but you cannot join with this client.");
            return false;
        }

        // If we should remove the reboot prefix, do so
        if (ShouldRemoveRebootPrefix())
        {
            FString NewName = RemoveRebootPrefix(PlayerName);
            PlayerController->ServerChangeName(NewName);
            
            // Store the new name in the global usernames map
            Globals::playerUsernames.insert({ PlayerController, NewName.ToString() });
        }

        return true; // Allow connection
    }

    /**
     * Get the configuration status of reboot player settings
     * @return A string describing the current configuration
     */
    static FString GetRebootPlayerConfigStatus()
    {
        FString Status = L"Reboot Player Configuration:\n";
        Status += L"  Allow Reboot Players: " + (IsRebootPlayerAllowed() ? L"Enabled" : L"Disabled") + L"\n";
        Status += L"  Remove Reboot Prefix: " + (ShouldRemoveRebootPrefix() ? L"Enabled" : L"Disabled");
        return Status;
    }
};
