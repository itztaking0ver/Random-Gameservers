#include "XPComponent.h"
#include "../log.h"
#include "../globals.h"

// Implementation of XP Component functionality
// This file contains the actual implementation of XP-related functions

namespace XPComponentUtils
{
    /**
     * Handle starting new player XP initialization
     * This is called when a new player joins the game
     */
    void HandleStartingNewPlayerXP(AActor* NewPlayerActor)
    {
        if (!NewPlayerActor)
        {
            LOG_ERROR(LogPlayer, "NewPlayerActor is null in HandleStartingNewPlayerXP");
            return;
        }

        LOG_INFO(LogPlayer, "Initializing XP for new player");

        // Get the XP component
        auto XPComponent = UFortPlayerControllerAthenaXPComponent::GetXPComponent(NewPlayerActor);
        
        if (!XPComponent)
        {
            LOG_WARNING(LogPlayer, "No XP component found for new player");
            return;
        }

        // Register with quest manager
        bool bSuccess = UFortPlayerControllerAthenaXPComponent::RegisterWithQuestManager(XPComponent);
        
        if (bSuccess)
        {
            LOG_INFO(LogPlayer, "Successfully registered XP component with quest manager");
        }
        else
        {
            LOG_ERROR(LogPlayer, "Failed to register XP component with quest manager");
        }
    }

    /**
     * Check if a player has a valid XP component
     */
    bool HasValidXPComponent(AActor* PlayerActor)
    {
        if (!PlayerActor)
            return false;

        auto XPComponent = UFortPlayerControllerAthenaXPComponent::GetXPComponent(PlayerActor);
        return XPComponent != nullptr;
    }

    /**
     * Get XP component status for debugging
     */
    void LogXPComponentStatus(AActor* PlayerActor)
    {
        if (!PlayerActor)
        {
            LOG_INFO(LogPlayer, "PlayerActor is null");
            return;
        }

        auto XPComponent = UFortPlayerControllerAthenaXPComponent::GetXPComponent(PlayerActor);
        
        if (!XPComponent)
        {
            LOG_INFO(LogPlayer, "No XP component found");
            return;
        }

        bool bRegistered = UFortPlayerControllerAthenaXPComponent::IsRegisteredWithQuestManager(XPComponent);
        LOG_INFO(LogPlayer, "XP Component Status - Registered with Quest Manager: {}", bRegistered ? "Yes" : "No");
    }
}
