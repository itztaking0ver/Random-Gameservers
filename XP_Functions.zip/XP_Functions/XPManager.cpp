#include "XPManager.h"
#include "../log.h"
#include "../globals.h"
#include "../GameplayStatics.h"

// Static member initialization
bool UFortXPManager::bXPSystemInitialized = false;
int UFortXPManager::TotalXPAwarded = 0;
int UFortXPManager::TotalPlayersProcessed = 0;

void UFortXPManager::InitializeXPSystem()
{
    if (bXPSystemInitialized)
    {
        LOG_WARNING(LogPlayer, "XP System already initialized");
        return;
    }

    LOG_INFO(LogPlayer, "Initializing XP System...");
    
    // Initialize XP system components
    bXPSystemInitialized = true;
    TotalXPAwarded = 0;
    TotalPlayersProcessed = 0;
    
    LOG_INFO(LogPlayer, "XP System initialized successfully");
}

void UFortXPManager::ShutdownXPSystem()
{
    if (!bXPSystemInitialized)
    {
        LOG_WARNING(LogPlayer, "XP System not initialized");
        return;
    }

    LOG_INFO(LogPlayer, "Shutting down XP System...");
    LOG_INFO(LogPlayer, "Total XP Awarded: {}", TotalXPAwarded);
    LOG_INFO(LogPlayer, "Total Players Processed: {}", TotalPlayersProcessed);
    
    bXPSystemInitialized = false;
    TotalXPAwarded = 0;
    TotalPlayersProcessed = 0;
    
    LOG_INFO(LogPlayer, "XP System shutdown complete");
}

void UFortXPManager::ProcessXPForPlayer(AActor* PlayerActor, int XPAmount, const FString& XPType)
{
    if (!bXPSystemInitialized)
    {
        LOG_ERROR(LogPlayer, "XP System not initialized");
        return;
    }

    if (!PlayerActor)
    {
        LOG_ERROR(LogPlayer, "PlayerActor is null in ProcessXPForPlayer");
        return;
    }

    if (XPAmount <= 0)
    {
        LOG_WARNING(LogPlayer, "Invalid XP amount: {}", XPAmount);
        return;
    }

    LOG_INFO(LogPlayer, "Processing {} XP of type '{}' for player", XPAmount, XPType.ToString());

    // Award the XP
    AwardXP(PlayerActor, XPAmount, true);
    
    // Update statistics
    TotalXPAwarded += XPAmount;
}

void UFortXPManager::AwardXP(AActor* PlayerActor, int XPAmount, bool bNotifyClient)
{
    if (!PlayerActor)
    {
        LOG_ERROR(LogPlayer, "PlayerActor is null in AwardXP");
        return;
    }

    // Get the XP component
    auto XPComponent = UFortPlayerControllerAthenaXPComponent::GetXPComponent(PlayerActor);
    
    if (!XPComponent)
    {
        LOG_WARNING(LogPlayer, "No XP component found for player");
        return;
    }

    LOG_INFO(LogPlayer, "Awarding {} XP to player", XPAmount);

    // Here you would implement the actual XP awarding logic
    // This is a placeholder for the actual implementation
    
    if (bNotifyClient)
    {
        LOG_INFO(LogPlayer, "Notifying client of XP award");
        // Implement client notification here
    }
}

int UFortXPManager::GetPlayerTotalXP(AActor* PlayerActor)
{
    if (!PlayerActor)
    {
        LOG_ERROR(LogPlayer, "PlayerActor is null in GetPlayerTotalXP");
        return -1;
    }

    auto XPComponent = UFortPlayerControllerAthenaXPComponent::GetXPComponent(PlayerActor);
    
    if (!XPComponent)
    {
        LOG_WARNING(LogPlayer, "No XP component found for player");
        return -1;
    }

    // Placeholder implementation
    // In a real implementation, you would read the actual XP value from the component
    LOG_INFO(LogPlayer, "Getting total XP for player");
    return 0; // Placeholder return value
}

int UFortXPManager::GetPlayerLevel(AActor* PlayerActor)
{
    if (!PlayerActor)
    {
        LOG_ERROR(LogPlayer, "PlayerActor is null in GetPlayerLevel");
        return -1;
    }

    int TotalXP = GetPlayerTotalXP(PlayerActor);
    
    if (TotalXP == -1)
        return -1;

    // Simple level calculation (placeholder)
    // In a real implementation, you would use a proper level curve
    int Level = (TotalXP / 1000) + 1; // 1000 XP per level
    
    LOG_INFO(LogPlayer, "Player level: {}", Level);
    return Level;
}

bool UFortXPManager::IsXPSystemInitialized()
{
    return bXPSystemInitialized;
}
