# XP Functions Collection

This folder contains all XP (Experience Points) related functions extracted from the Frost-GS codebase.

## Files Overview

### XPComponent.h & XPComponent.cpp
- **Purpose**: Core XP component functionality
- **Key Functions**:
  - `GetXPComponent()` - Retrieves XP component from player actor
  - `RegisterWithQuestManager()` - Registers XP component with quest system
  - `IsRegisteredWithQuestManager()` - Checks registration status
  - `InitializeXPForPlayer()` - Sets up XP for new players

### XPManager.h & XPManager.cpp
- **Purpose**: High-level XP system management
- **Key Functions**:
  - `InitializeXPSystem()` - Initializes the entire XP system
  - `ShutdownXPSystem()` - Cleanup XP system resources
  - `ProcessXPForPlayer()` - Processes XP awards for players
  - `AwardXP()` - Awards XP to specific players
  - `GetPlayerTotalXP()` - Retrieves player's total XP
  - `GetPlayerLevel()` - Calculates player level from XP

## Usage

```cpp
#include "XP_Functions/XPComponent.h"
#include "XP_Functions/XPManager.h"

// Initialize XP system
UFortXPManager::InitializeXPSystem();

// Award XP to a player
UFortXPManager::AwardXP(PlayerActor, 1000, true);

// Get player level
int Level = UFortXPManager::GetPlayerLevel(PlayerActor);
```

## Integration

These functions were extracted from the original codebase where XP functionality was scattered across multiple files. The main integration point was in `FortGameModeAthena.cpp` where XP components are initialized for new players.

## Notes

- All functions include proper error checking and logging
- The system maintains statistics for debugging and monitoring
- XP component registration with quest manager is handled automatically
- Functions are designed to be thread-safe and robust

## Reboot Player Management

### RebootPlayerManager.h & RebootPlayerManager.cpp
- **Purpose**: Manages reboot player functionality and name handling
- **Key Functions**:
  - `IsRebootPlayerAllowed()` - Check if reboot players can join
  - `SetRebootPlayerAllowed()` - Enable/disable reboot player access
  - `ShouldRemoveRebootPrefix()` - Check if reboot prefix should be removed
  - `SetRemoveRebootPrefix()` - Enable/disable prefix removal
  - `IsRebootPlayer()` - Check if player name has reboot prefix
  - `RemoveRebootPrefix()` - Remove "reboot_" from player names
  - `HandleRebootPlayerConnection()` - Process reboot player connections
  - `GetRebootPlayerConfigStatus()` - Get current configuration status

### Usage Example

```cpp
#include "XP_Functions/RebootPlayerManager.h"

// Check if reboot players are allowed
if (UFortRebootPlayerManager::IsRebootPlayerAllowed())
{
    // Handle reboot player connection
    bool bAllowed = UFortRebootPlayerManager::HandleRebootPlayerConnection(PlayerController);
}

// Get configuration status
FString Status = UFortRebootPlayerManager::GetRebootPlayerConfigStatus();
```

### Configuration Variables

- `bAllowRebootPlayer` - Controls whether players with "reboot_" prefix can join
- `bRemoveRebootFromPlayerName` - Controls whether to remove the "reboot_" prefix from player names

### Integration Notes

These functions were extracted from `globals.h` and `NetDriver.cpp` where they were used to:
- Block or allow players with "reboot_" prefix in their names
- Optionally remove the "reboot_" prefix from player names
- Store cleaned usernames in the global player usernames map
